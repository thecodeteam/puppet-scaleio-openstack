Overview

This library provides REST API access for ScaleIO 2.0.

Right now it is designed to be used by nova ephemeral storage driver for ScaleIO and is not intended for general use as ScaleIO python client library.
